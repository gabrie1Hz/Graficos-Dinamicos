<?php
// BD.php

// Datos de conexión a MySQL (phpMyAdmin usa MySQL local en la mayoría de los casos)
$servername = "localhost";         // O "127.0.0.1"
$username   = "root";             // Usuario de MySQL (por defecto en phpMyAdmin)
$password   = "";  // Tu contraseña real de MySQL
$dbname     = "dashboard";        // Nombre de la base de datos que aparece en phpMyAdmin

// Crear conexión usando mysqli
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Ajustar el conjunto de caracteres a UTF-8 (recomendado)
$conn->set_charset("utf8");
?>
