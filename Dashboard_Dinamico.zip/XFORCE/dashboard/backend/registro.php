<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
// Datos de conexión a MySQL
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "dashboard";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener datos del formulario
$usuario  = $_POST['username'];
$email    = $_POST['email'];
$pass     = $_POST['password'];

// Hashear la contraseña
$passwordHash = password_hash($pass, PASSWORD_DEFAULT);

// Insertar en la tabla usuarios
$sql = "INSERT INTO usuarios (usuario, email, password) VALUES ('$usuario', '$email', '$passwordHash')";

if ($conn->query($sql) === TRUE) {
    // Tras registro exitoso, redirigir a graficos.php
    echo "<script>alert('Registro exitoso'); 
          setTimeout(function(){ window.location.href = '../public/graficos.php'; }, 1000);
          </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
