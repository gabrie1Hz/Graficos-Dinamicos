<?php
// getCategories.php
header('Content-Type: application/json');

// Incluir el archivo de conexión
require_once 'BD.php';

// Consulta para obtener las categorías
$sql = "SELECT idcategorias, categoria FROM categorias";
$result = $conn->query($sql);

$categorias = [];

// Verificar si la consulta fue exitosa
if ($result) {
    // Recorrer resultados
    while ($row = $result->fetch_assoc()) {
        $categorias[] = $row;
    }
    // Devolver en formato JSON
    echo json_encode($categorias);
} else {
    // Si hubo error, devolver un objeto JSON con la información del error
    echo json_encode(["error" => $conn->error]);
}

// Cerrar conexión
$conn->close();
?>
