<?php
// insertProducto.php
header('Content-Type: text/plain');

// Incluir el archivo de conexión
require_once 'BD.php';

// Recibir datos por POST (nombre, stock, precio, costo, idcategoria)
$nombre = $_POST['nombre'] ?? '';
$stock  = $_POST['stock'] ?? 0;
$precio = $_POST['precio'] ?? 0;
$costo  = $_POST['costo'] ?? 0;
$idcat  = $_POST['idcategoria'] ?? 0;

// Validar datos básicos
if (!empty($nombre) && $stock >= 0 && $precio >= 0 && $costo >= 0 && $idcat > 0) {
    // Preparar la consulta
    $stmt = $conn->prepare("
        INSERT INTO productos (nombre_producto, stock, precio, costo, idcategorias)
        VALUES (?, ?, ?, ?, ?)
    ");
    if ($stmt === false) {
        die("Error en la preparación: " . $conn->error);
    }

    // Enlazar parámetros
    $stmt->bind_param("sdddi", $nombre, $stock, $precio, $costo, $idcat);

    // Ejecutar
    if ($stmt->execute()) {
        echo "Producto insertado correctamente";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Datos inválidos o incompletos";
}

// Cerrar conexión
$conn->close();
?>
