<?php
// Datos de conexión a MySQL
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "dashboard";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener datos del formulario
$usuario    = $_POST['username'];
$contrasena = $_POST['password'];

// Buscar el usuario en la base de datos
$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Verificar la contraseña con password_verify() si está hasheada
    if (password_verify($contrasena, $row['password'])) {
        // Redirigir a graficos.php tras login exitoso
        echo "<script>alert('Iniciando Sesión...'); 
              setTimeout(function(){ window.location.href = '../public/graficos.php'; }, 1000);
              </script>";
    } else {
        echo "Usuario o contraseña incorrectos";
    }
} else {
    echo "Usuario o contraseña incorrectos";
}

$conn->close();
?>
