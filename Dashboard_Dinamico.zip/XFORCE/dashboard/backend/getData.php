<?php
header('Content-Type: application/json');
require_once '../backend/BD.php';

// Obtener totales de productos, clientes y ventas
$sqlProductos = "SELECT COUNT(*) as total FROM productos";
$sqlClientes = "SELECT COUNT(*) as total FROM cliente";
$sqlVentas = "SELECT COUNT(*) as total FROM ventas";

$resultProductos = $conn->query($sqlProductos);
$resultClientes = $conn->query($sqlClientes);
$resultVentas = $conn->query($sqlVentas);

$data = [
    "productos" => ($resultProductos->num_rows > 0) ? $resultProductos->fetch_assoc()['total'] : 0,
    "clientes" => ($resultClientes->num_rows > 0) ? $resultClientes->fetch_assoc()['total'] : 0,
    "ventas" => ($resultVentas->num_rows > 0) ? $resultVentas->fetch_assoc()['total'] : 0
];

echo json_encode($data);
$conn->close();
?>