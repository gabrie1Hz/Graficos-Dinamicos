<?php
require "../backend/BD.php";

// Consultar el total de productos
$resultProductos = $conn->query("SELECT COUNT(*) as total FROM productos");
$totalProductos = ($resultProductos->num_rows > 0) ? $resultProductos->fetch_assoc()['total'] : 0;

// Consultar el total de clientes
$resultClientes = $conn->query("SELECT COUNT(*) as total FROM cliente");
$totalClientes = ($resultClientes->num_rows > 0) ? $resultClientes->fetch_assoc()['total'] : 0;

// Consultar el total de ventas
$resultVentas = $conn->query("SELECT COUNT(*) as total FROM ventas");
$totalVentas = ($resultVentas->num_rows > 0) ? $resultVentas->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard de Reportes de Graficos Dinamicos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Librerías externas -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/papaparse@5.3.2/papaparse.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js"></script>

    <!-- Enlazar hoja de estilos -->
    <link rel="stylesheet" href="css/Styles.css">
</head>
<body>

<div class="dashboard">
    <!-- Sidebar de navegación -->
    <nav class="sidebar">
        <h2 class="logo">Dashboard</h2>
        <ul>
            <li><a href="#" id="btnVisionGeneral">Visión General</a></li>
            <li><a href="#" id="btnAnalisis">Análisis</a></li>
            <li><a href="#" id="btnReporte">Reporte</a></li>
            <li><a href="#" id="btnConfiguracion">Configuración</a></li>
            <li><a href="#" id="btnCargarDatos">Cargar Datos</a></li>
        </ul>
    </nav>

    <!-- Contenido principal -->
    <div class="main-content">
        <header>
            <h1>Bienvenido Administrador</h1>
            <p>Aquí están tus últimas estadísticas.</p>
        </header>

        <!-- Sección de Visión General -->
        <section id="visionGeneral" class="seccion">
            <h2>Visión General</h2>
            <div class="widgets">
                <div class="widget">
                    <h3>Productos</h3>
                    <p id="totalProductos"></p>
                </div>
                <div class="widget">
                    <h3>Clientes</h3>
                    <p id="totalClientes"></p>
                </div>
                <div class="widget">
                    <h3>Ventas</h3>
                    <p id="totalVentas"></p>
                </div>
            </div>
            <div class="charts">
                <div class="chart-container">
                    <canvas id="pieChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </section>

        <!-- Sección de Análisis -->
        <section id="analisis" class="seccion" style="display: none;">
            <h2>Análisis</h2>
            <p>Aquí van los gráficos de análisis.</p>
            <div class="charts">
                <div class="chart-container">
                    <canvas id="pieChartAnalisis"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="barChartAnalisis"></canvas>
                </div>
            </div>
        </section>

        <!-- Sección de Reporte -->
        <section id="reporte" class="seccion" style="display: none;">
            <h2>Reporte</h2>
            <p>Reporte detallado del dashboard.</p>
            <div id="reporteContent">
                <div class="widgets">
                    <div class="widget">
                        <h3>Productos</h3>
                        <p id="totalProductosReporte">1,234</p>
                    </div>
                    <div class="widget">
                        <h3>Clientes</h3>
                        <p id="totalClientesReporte">567</p>
                    </div>
                    <div class="widget">
                        <h3>Ventas</h3>
                        <p id="totalVentasReporte">89</p>
                    </div>
                </div>
                <div class="charts">
                    <div class="chart-container">
                        <canvas id="pieChartReporte"></canvas>
                    </div>
                    <div class="chart-container">
                        <canvas id="barChartReporte"></canvas>
                    </div>
                </div>
            </div>
            <button id="btnImprimirPDF">Imprimir PDF</button>
        </section>

        <!-- Sección de Configuración -->
        <section id="configuracion" class="seccion" style="display: none;">
            <h2>Configuración</h2>
            <p>Ajusta tus preferencias y configura tu cuenta (solo el administrador tiene acceso a estos cambios).</p>
            <div class="config-section">
                <h3>Perfil del Administrador</h3>
                <p>Actualiza tu nombre, email y contraseña.</p>
                <form id="formPerfil">
                    <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" value="Administrador">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="admin@ejemplo.com">
                    </div>
                    <div class="form-group">
                        <label for="currentPassword">Contraseña Actual:</label>
                        <input type="password" id="currentPassword" name="currentPassword" placeholder="Ingresa la contraseña actual">
                    </div>
                    <div class="form-group">
                        <label for="newPassword">Nueva Contraseña:</label>
                        <input type="password" id="newPassword" name="newPassword" placeholder="Ingresa la nueva contraseña">
                    </div>
                    <button type="submit">Guardar Cambios</button>
                </form>
            </div>
            <div class="config-section">
                <h3>Preferencias del Dashboard</h3>
                <form id="formPreferencias">
                    <div class="form-group">
                        <label for="tema">Tema:</label>
                        <select id="tema" name="tema">
                            <option value="claro">Claro</option>
                            <option value="oscuro">Oscuro</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Mostrar Widgets:</label>
                        <label><input type="checkbox" id="widgetProductos" name="widgetProductos" checked> Productos</label>
                        <label><input type="checkbox" id="widgetClientes" name="widgetClientes" checked> Clientes</label>
                        <label><input type="checkbox" id="widgetVentas" name="widgetVentas" checked> Ventas</label>
                    </div>
                    <button type="submit">Guardar Preferencias</button>
                </form>
            </div>
        </section>

        <!-- Sección de Cargar Datos -->
        <section id="cargarDatos" class="seccion" style="display: none;">
            <h2>Cargar Datos para Gráfica</h2>
            <div class="data-load-section">
                <h3>Selecciona un archivo (CSV, TXT, JSON, Excel)</h3>
                <input type="file" id="fileInput" accept=".csv, .txt, .json, .xlsx, .xls, .ods, .pdf, .png, .jpg" />
                <button id="btnCargarDatos">Cargar Datos</button>
            </div>

            <!-- Contenedor para ambas gráficas (barras y pastel) -->
            <div class="charts">
                <!-- Gráfica de Barras -->
                <div class="chart-container" style="margin-top:20px;">
                    <canvas id="fileChart"></canvas>
                </div>

                <!-- Gráfica de Pastel -->
                <div class="chart-container" style="margin-top:20px;">
                    <canvas id="fileChartPie"></canvas>
                </div>
            </div>
        </section>

<!-- Enlazar script principal -->
<script src="js/Script.js"></script>
</body>
</html>

