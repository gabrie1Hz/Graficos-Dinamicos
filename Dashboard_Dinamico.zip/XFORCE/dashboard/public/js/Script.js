// public/js/script.js

// 1) Declaramos variables globales para todas las gráficas
let chartPieVG, chartBarVG;          // Visión General
let chartPieAnalisis, chartBarAnalisis;
let chartPieReporte, chartBarReporte;

// Gráficas especiales para los datos cargados desde archivo
let fileChart;     // Gráfica de barras
let fileChartPie;  // Gráfica de pastel

document.addEventListener('DOMContentLoaded', () => {

    // ------------------------------------------------------------------------
    // 1) Función para inicializar TODAS las gráficas al cargar la página
    // ------------------------------------------------------------------------
    function inicializarGraficas() {
        // --- Gráficas de VISIÓN GENERAL ---
        chartPieVG = new Chart(
            document.getElementById('pieChart').getContext('2d'),
            {
                type: 'pie',
                data: {
                    labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                    datasets: [{
                        label: 'Sales Distribution',
                        data: [120, 190, 300, 500, 200, 300, 400, 450, 380, 420, 390],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)',
                            'rgba(0, 128, 128, 0.6)',
                            'rgba(220, 20, 60, 0.6)',
                            'rgba(128, 0, 128, 0.6)',
                            'rgba(255, 140, 0, 0.6)',
                            'rgba(0, 191, 255, 0.6)'
                        ],
                        borderColor: '#fff',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: true, position: 'top' } }
                }
            }
        );

        chartBarVG = new Chart(
            document.getElementById('barChart').getContext('2d'),
            {
                type: 'bar',
                data: {
                    labels: ['mango tommy', 'mango ataulfo', 'mango kent', 'mango piña', 'mango haden', 'mango durazno'],
                    datasets: [{
                        label: 'Distribución de Mangos',
                        data: [65, 59, 80, 81, 56, 70],
                        backgroundColor: [
                            'rgba(74, 144, 226, 0.8)',
                            'rgba(80, 227, 194, 0.8)',
                            'rgba(255, 205, 86, 0.8)',
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(153, 102, 255, 0.8)',
                            'rgba(255, 159, 64, 0.8)'
                        ],
                        borderColor: [
                            'rgba(74, 144, 226, 1)',
                            'rgba(80, 227, 194, 1)',
                            'rgba(255, 205, 86, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: { duration: 1000, easing: 'easeInOutQuart' },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false } },
                        y: { grid: { color: '#eaeaea' }, beginAtZero: true }
                    }
                }
            }
        );

        // --- Gráficas de ANÁLISIS ---
        chartPieAnalisis = new Chart(
            document.getElementById('pieChartAnalisis').getContext('2d'),
            {
                type: 'pie',
                data: {
                    labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                    datasets: [{
                        label: 'Sales Distribution',
                        data: [120, 190, 300, 500, 200, 300, 400, 450, 380, 420, 390],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)',
                            'rgba(0, 128, 128, 0.6)',
                            'rgba(220, 20, 60, 0.6)',
                            'rgba(128, 0, 128, 0.6)',
                            'rgba(255, 140, 0, 0.6)',
                            'rgba(0, 191, 255, 0.6)'
                        ],
                        borderColor: '#fff',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: true, position: 'top' } }
                }
            }
        );

        chartBarAnalisis = new Chart(
            document.getElementById('barChartAnalisis').getContext('2d'),
            {
                type: 'bar',
                data: {
                    labels: ['mango tommy', 'mango ataulfo', 'mango kent', 'mango piña', 'mango haden', 'mango durazno'],
                    datasets: [{
                        label: 'Distribución de Mangos',
                        data: [65, 59, 80, 81, 56, 70],
                        backgroundColor: [
                            'rgba(74, 144, 226, 0.8)',
                            'rgba(80, 227, 194, 0.8)',
                            'rgba(255, 205, 86, 0.8)',
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(153, 102, 255, 0.8)',
                            'rgba(255, 159, 64, 0.8)'
                        ],
                        borderColor: [
                            'rgba(74, 144, 226, 1)',
                            'rgba(80, 227, 194, 1)',
                            'rgba(255, 205, 86, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: { duration: 1000, easing: 'easeInOutQuart' },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false } },
                        y: { grid: { color: '#eaeaea' }, beginAtZero: true }
                    }
                }
            }
        );

        // --- Gráficas de REPORTE ---
        chartPieReporte = new Chart(
            document.getElementById('pieChartReporte').getContext('2d'),
            {
                type: 'pie',
                data: {
                    labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                    datasets: [{
                        label: 'Sales Distribution',
                        data: [120, 190, 300, 500, 200, 300, 400, 450, 380, 420, 390],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.6)',
                            'rgba(54, 162, 235, 0.6)',
                            'rgba(255, 206, 86, 0.6)',
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(153, 102, 255, 0.6)',
                            'rgba(255, 159, 64, 0.6)',
                            'rgba(0, 128, 128, 0.6)',
                            'rgba(220, 20, 60, 0.6)',
                            'rgba(128, 0, 128, 0.6)',
                            'rgba(255, 140, 0, 0.6)',
                            'rgba(0, 191, 255, 0.6)'
                        ],
                        borderColor: '#fff',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: true, position: 'top' } }
                }
            }
        );

        chartBarReporte = new Chart(
            document.getElementById('barChartReporte').getContext('2d'),
            {
                type: 'bar',
                data: {
                    labels: ['mango tommy', 'mango ataulfo', 'mango kent', 'mango piña', 'mango haden', 'mango durazno'],
                    datasets: [{
                        label: 'Distribución de Mangos',
                        data: [65, 59, 80, 81, 56, 70],
                        backgroundColor: [
                            'rgba(74, 144, 226, 0.8)',
                            'rgba(80, 227, 194, 0.8)',
                            'rgba(255, 205, 86, 0.8)',
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(153, 102, 255, 0.8)',
                            'rgba(255, 159, 64, 0.8)'
                        ],
                        borderColor: [
                            'rgba(74, 144, 226, 1)',
                            'rgba(80, 227, 194, 1)',
                            'rgba(255, 205, 86, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    animation: { duration: 1000, easing: 'easeInOutQuart' },
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false } },
                        y: { grid: { color: '#eaeaea' }, beginAtZero: true }
                    }
                }
            }
        );
    }

    // ------------------------------------------------------------------------
    // 2) Función para actualizar TODAS las gráficas con nuevos datos
    // ------------------------------------------------------------------------
    function actualizarTodasLasGraficas(labels, valores) {
        // Visión General
        chartPieVG.data.labels = labels;
        chartPieVG.data.datasets[0].data = valores;
        chartPieVG.update();

        chartBarVG.data.labels = labels;
        chartBarVG.data.datasets[0].data = valores;
        chartBarVG.update();

        // Análisis
        chartPieAnalisis.data.labels = labels;
        chartPieAnalisis.data.datasets[0].data = valores;
        chartPieAnalisis.update();

        chartBarAnalisis.data.labels = labels;
        chartBarAnalisis.data.datasets[0].data = valores;
        chartBarAnalisis.update();

        // Reporte
        chartPieReporte.data.labels = labels;
        chartPieReporte.data.datasets[0].data = valores;
        chartPieReporte.update();

        chartBarReporte.data.labels = labels;
        chartBarReporte.data.datasets[0].data = valores;
        chartBarReporte.update();
    }

    // Llamamos a la función que inicializa TODAS las gráficas al cargar la página
    inicializarGraficas();

    // ------------------------------------------------------------------------
    // 3) Manejo de navegación entre secciones
    // ------------------------------------------------------------------------
    const botones = {
        btnVisionGeneral: 'visionGeneral',
        btnAnalisis: 'analisis',
        btnReporte: 'reporte',
        btnConfiguracion: 'configuracion',
        btnCargarDatos: 'cargarDatos'
    };

    function ocultarSecciones() {
        Object.values(botones).forEach(seccion => {
            document.getElementById(seccion).style.display = 'none';
        });
    }

    function mostrarSeccion(seccionId) {
        ocultarSecciones();
        document.getElementById(seccionId).style.display = 'block';
    }

    Object.keys(botones).forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', () => {
                mostrarSeccion(botones[id]);
            });
        }
    });

    // Mostrar por defecto la sección de Visión General
    mostrarSeccion('visionGeneral');

    // ------------------------------------------------------------------------
    // 4) Generar PDF (Reporte)
    // ------------------------------------------------------------------------
    document.getElementById('btnImprimirPDF').addEventListener('click', () => {
        const reporteElement = document.getElementById('reporteContent');
        html2canvas(reporteElement, { scale: 2 }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jspdf.jsPDF('p', 'mm', 'a4');

            // Configuración de márgenes
            const marginX = 15;
            const marginY = 25;
            const borderWidth = pdf.internal.pageSize.getWidth() - 2 * (marginX - 5);
            const borderHeight = pdf.internal.pageSize.getHeight() - 2 * (marginY - 5);
            const pdfWidth = borderWidth - 20;
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            // Fondo del PDF
            pdf.setFillColor(240, 240, 240);
            pdf.rect(0, 0, pdf.internal.pageSize.getWidth(), pdf.internal.pageSize.getHeight(), 'F');

            // Borde decorativo
            pdf.setDrawColor(200, 150, 50);
            pdf.setLineWidth(3);
            pdf.rect(marginX - 5, marginY - 10, borderWidth, borderHeight);

            // Obtener fecha y hora actual
            const fechaActual = new Date();
            const fechaFormateada = fechaActual.toLocaleDateString();
            const horaFormateada = fechaActual.toLocaleTimeString();

            // Agregar encabezado
            pdf.setFont('helvetica', 'bold');
            pdf.setFontSize(18);
            pdf.text('Reporte de Ventas y Análisis', marginX, marginY);

            pdf.setFontSize(12);
            pdf.setFont('helvetica', 'normal');
            pdf.text(`Fecha: ${fechaFormateada}`, marginX, marginY + 8);
            pdf.text(`Hora: ${horaFormateada}`, marginX, marginY + 14);

            // Agregar la imagen del reporte
            pdf.addImage(imgData, 'PNG', marginX + 5, marginY + 20, pdfWidth, pdfHeight);

            // Agregar marca "HubTech" en la parte inferior izquierda
            pdf.setFont('helvetica', 'bold');
            pdf.setFontSize(14);
            pdf.setTextColor(100, 100, 100);
            const hubtechX = marginX + 10;
            const hubtechY = pdf.internal.pageSize.getHeight() - marginY - 5;
            pdf.text('HubTech', hubtechX, hubtechY);

            pdf.save('reporte.pdf');
        });
    });

    // ------------------------------------------------------------------------
    // 5) Modo Claro/Oscuro en Preferencias
    // ------------------------------------------------------------------------
    const formPreferencias = document.getElementById('formPreferencias');
    const selectTema = document.getElementById('tema');
    const temaGuardado = localStorage.getItem('temaDashboard');

    if (temaGuardado === 'oscuro') {
        document.body.classList.add('dark-mode');
        selectTema.value = 'oscuro';
    }

    formPreferencias.addEventListener('submit', (e) => {
        e.preventDefault();
        const temaSeleccionado = selectTema.value;
        if (temaSeleccionado === 'oscuro') {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
        localStorage.setItem('temaDashboard', temaSeleccionado);
        alert(`Preferencias aplicadas: Modo ${temaSeleccionado}`);
    });

    // ------------------------------------------------------------------------
    // 6) Cargar Datos desde Archivo para gráfica interactiva
    //    y actualizar TODAS las gráficas
    // ------------------------------------------------------------------------
    const fileInput = document.getElementById('fileInput');
    const btnCargarDatos = document.getElementById('btnCargarDatos');

    btnCargarDatos.addEventListener('click', () => {
        const file = fileInput.files[0];
        if (!file) {
            alert("Selecciona un archivo primero.");
            return;
        }
        const fileName = file.name.toLowerCase();

        if (fileName.endsWith('.csv') || fileName.endsWith('.txt')) {
            Papa.parse(file, {
                complete: function(results) {
                    const rows = results.data;
                    if (rows.length < 2) {
                        alert("El archivo no tiene suficientes datos.");
                        return;
                    }
                    const labels = [];
                    const valores = [];
                    for (let i = 1; i < rows.length; i++) {
                        const row = rows[i];
                        if (row.length >= 2) {
                            labels.push(row[0]);
                            valores.push(parseFloat(row[1]) || 0);
                        }
                    }
                    dibujarGraficaArchivo(labels, valores);
                },
                error: function(err) {
                    console.error(err);
                    alert("Error al parsear el archivo CSV/TXT.");
                }
            });
        } else if (fileName.endsWith('.json')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const data = JSON.parse(e.target.result);
                    const labels = data.map(item => item.label);
                    const valores = data.map(item => item.value);
                    dibujarGraficaArchivo(labels, valores);
                } catch (ex) {
                    console.error(ex);
                    alert("Error al parsear el archivo JSON.");
                }
            };
            reader.readAsText(file);
        } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls') || fileName.endsWith('.ods')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                if (jsonData.length < 2) {
                    alert("La hoja de Excel no tiene suficientes datos.");
                    return;
                }
                const labels = [];
                const valores = [];
                for (let i = 1; i < jsonData.length; i++) {
                    const row = jsonData[i];
                    if (row.length >= 2) {
                        labels.push(row[0]);
                        valores.push(parseFloat(row[1]) || 0);
                    }
                }
                dibujarGraficaArchivo(labels, valores);
            };
            reader.readAsArrayBuffer(file);
        } else if (fileName.endsWith('.pdf') || fileName.endsWith('.png') ||
            fileName.endsWith('.jpg') || fileName.endsWith('.jpeg')) {
            alert("La extracción de datos de PDF o imágenes no está implementada en este ejemplo.");
        } else {
            alert("Formato de archivo no soportado.");
        }
    });

    // Función que dibuja las gráficas (barras y pastel) del archivo
    // y actualiza las demás gráficas del dashboard
    function dibujarGraficaArchivo(labels, valores) {
        // Destruir gráficas previas si existen
        if (fileChart) {
            fileChart.destroy();
        }
        if (fileChartPie) {
            fileChartPie.destroy();
        }

        // 1) Crear la gráfica de BARRAS
        const ctxBar = document.getElementById('fileChart').getContext('2d');
        fileChart = new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Datos del Archivo (Barras)',
                    data: valores,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true } }
            }
        });

        // 2) Crear la gráfica de PASTEL
        const ctxPie = document.getElementById('fileChartPie').getContext('2d');
        fileChartPie = new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Datos del Archivo (Pastel)',
                    data: valores,
                    // Asigna distintos colores si quieres diferenciar cada sector
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                        // Añade más colores si hay más de 6 valores
                    ],
                    borderColor: '#fff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            }
        });

        // <-- ACTUALIZAR TODAS LAS GRÁFICAS DEL DASHBOARD CON ESTOS DATOS -->
        actualizarTodasLasGraficas(labels, valores);
    }
});

// ------------------------------------------------------------------------
// 7) Al cargar el DOM, actualizamos los totales del Dashboard
// ------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', async () => {
    async function obtenerTotales() {
        try {
            const respuesta = await fetch('../backend/getData.php'); // Ajusta la ruta si es necesario
            return await respuesta.json();
        } catch (error) {
            console.error("Error obteniendo los totales:", error);
        }
    }

    async function actualizarTotales() {
        const datos = await obtenerTotales();
        if (!datos) return;

        document.getElementById('totalProductos').textContent = datos.productos;
        document.getElementById('totalClientes').textContent = datos.clientes;
        document.getElementById('totalVentas').textContent = datos.ventas;

        // Asumiendo que en la sección de Reporte hay elementos con estos IDs:
        document.getElementById('totalProductosReporte').textContent = datos.productos;
        document.getElementById('totalClientesReporte').textContent = datos.clientes;
        document.getElementById('totalVentasReporte').textContent = datos.ventas;
    }

    actualizarTotales();
});
